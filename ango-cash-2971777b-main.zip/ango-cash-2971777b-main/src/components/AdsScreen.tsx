import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Play, 
  Clock, 
  Zap, 
  Star,
  CheckCircle,
  Lock,
  Volume2,
  VolumeX
} from "lucide-react";

interface Ad {
  id: string;
  title: string;
  duration: number;
  reward: number;
  type: "standard" | "premium" | "sponsored";
  thumbnail: string;
}

const mockAds: Ad[] = [
  { id: "1", title: "Unitel - Sempre Conectado", duration: 30, reward: 100, type: "premium", thumbnail: "" },
  { id: "2", title: "BAI - O seu banco", duration: 15, reward: 50, type: "standard", thumbnail: "" },
  { id: "3", title: "Multicaixa Express", duration: 60, reward: 200, type: "sponsored", thumbnail: "" },
  { id: "4", title: "Kero - Compras Online", duration: 30, reward: 80, type: "standard", thumbnail: "" },
  { id: "5", title: "TAAG - Voe mais alto", duration: 45, reward: 150, type: "premium", thumbnail: "" },
];

export function AdsScreen() {
  const [isWatching, setIsWatching] = useState(false);
  const [currentAd, setCurrentAd] = useState<Ad | null>(null);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [completedAds, setCompletedAds] = useState<string[]>([]);
  const [earnings, setEarnings] = useState(0);

  const startAd = useCallback((ad: Ad) => {
    setCurrentAd(ad);
    setTimeRemaining(ad.duration);
    setIsWatching(true);
  }, []);

  const completeAd = useCallback(() => {
    if (currentAd) {
      setCompletedAds(prev => [...prev, currentAd.id]);
      setEarnings(prev => prev + currentAd.reward);
    }
    setIsWatching(false);
    setCurrentAd(null);
  }, [currentAd]);

  useEffect(() => {
    if (!isWatching || timeRemaining <= 0) return;

    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          completeAd();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isWatching, timeRemaining, completeAd]);

  const getTypeColor = (type: string) => {
    switch (type) {
      case "premium": return "gold";
      case "sponsored": return "diamond";
      default: return "secondary";
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "premium": return "Premium";
      case "sponsored": return "Patrocinado";
      default: return "Standard";
    }
  };

  if (isWatching && currentAd) {
    const progress = ((currentAd.duration - timeRemaining) / currentAd.duration) * 100;

    return (
      <motion.div 
        className="fixed inset-0 z-50 flex flex-col bg-background"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        {/* Ad Video Area */}
        <div className="relative flex-1 bg-secondary">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <Play className="mx-auto mb-4 h-16 w-16 text-primary animate-pulse" />
              <h2 className="font-display text-xl font-semibold">{currentAd.title}</h2>
              <p className="mt-2 text-muted-foreground">Reproduzindo anúncio...</p>
            </div>
          </div>

          {/* Mute Button */}
          <button 
            onClick={() => setIsMuted(!isMuted)}
            className="absolute right-4 top-4 rounded-full bg-background/50 p-3 backdrop-blur-sm"
          >
            {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
          </button>
        </div>

        {/* Progress Bar and Info */}
        <div className="border-t border-border bg-card p-4 safe-area-inset-bottom">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span className="font-mono text-lg font-bold">{timeRemaining}s</span>
            </div>
            <Badge variant="success" className="gap-1">
              <Zap className="h-3 w-3" />
              +{currentAd.reward} AOA
            </Badge>
          </div>
          <Progress value={progress} variant="gold" className="h-2" />
          <p className="mt-3 text-center text-xs text-muted-foreground">
            Assista o anúncio completo para ganhar sua recompensa
          </p>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24 pt-4">
      {/* Header */}
      <motion.header 
        className="px-4 pb-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="font-display text-2xl font-bold">Anúncios</h1>
        <p className="text-muted-foreground">Assista e ganhe recompensas</p>
      </motion.header>

      {/* Earnings Summary */}
      <motion.div 
        className="px-4 pb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card variant="gold">
          <CardContent className="flex items-center justify-between p-5">
            <div>
              <p className="text-sm text-muted-foreground">Ganhos de hoje</p>
              <p className="font-display text-2xl font-bold">
                {earnings.toLocaleString("pt-AO")} AOA
              </p>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-success" />
              <span className="text-sm text-muted-foreground">
                {completedAds.length} assistidos
              </span>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Ads List */}
      <motion.div 
        className="px-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <h2 className="mb-3 font-display font-semibold">Disponíveis Agora</h2>
        <div className="space-y-3">
          <AnimatePresence>
            {mockAds.map((ad, index) => {
              const isCompleted = completedAds.includes(ad.id);
              
              return (
                <motion.div
                  key={ad.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 * index }}
                >
                  <Card 
                    variant={isCompleted ? "flat" : "default"}
                    className={isCompleted ? "opacity-60" : ""}
                  >
                    <CardContent className="flex items-center gap-4 p-4">
                      {/* Thumbnail */}
                      <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-primary/10">
                        {isCompleted ? (
                          <CheckCircle className="h-8 w-8 text-success" />
                        ) : (
                          <Play className="h-8 w-8 text-primary" />
                        )}
                      </div>

                      {/* Info */}
                      <div className="flex-1">
                        <div className="mb-1 flex items-center gap-2">
                          <Badge variant={getTypeColor(ad.type) as any}>
                            {ad.type === "premium" && <Star className="mr-1 h-3 w-3" />}
                            {getTypeLabel(ad.type)}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {ad.duration}s
                          </span>
                        </div>
                        <h3 className="font-medium">{ad.title}</h3>
                        <p className="text-sm font-semibold text-success">
                          +{ad.reward} AOA
                        </p>
                      </div>

                      {/* Action */}
                      {isCompleted ? (
                        <Badge variant="success">Assistido</Badge>
                      ) : (
                        <Button
                          variant="gold"
                          size="sm"
                          onClick={() => startAd(ad)}
                        >
                          Assistir
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </motion.div>

      {/* Locked Premium Section */}
      <motion.div 
        className="mt-6 px-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <h2 className="mb-3 font-display font-semibold text-muted-foreground">
          Desbloqueie mais
        </h2>
        <Card variant="premium" className="border-dashed">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
              <Lock className="h-6 w-6 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="font-medium">Anúncios Premium</h3>
              <p className="text-sm text-muted-foreground">
                Torne-se nível Diamante para desbloquear
              </p>
            </div>
            <Badge variant="diamond">Diamante</Badge>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
