import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { 
  Smartphone,
  Mail,
  ArrowLeft,
  ChevronRight,
  Loader2,
  Eye,
  EyeOff,
  Sparkles
} from "lucide-react";
import { toast } from "sonner";

interface AuthScreenProps {
  onAuth: () => void;
}

type AuthMode = "select" | "phone" | "email" | "otp";

export function AuthScreen({ onAuth }: AuthScreenProps) {
  const [mode, setMode] = useState<AuthMode>("select");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isRegister, setIsRegister] = useState(false);

  const handlePhoneSubmit = () => {
    if (phone.length < 9) {
      toast.error("Número de telefone inválido");
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setMode("otp");
      toast.success("Código enviado para " + phone);
    }, 1500);
  };

  const handleEmailSubmit = () => {
    if (!email.includes("@") || password.length < 6) {
      toast.error("Verifique seus dados");
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      toast.success(isRegister ? "Conta criada com sucesso!" : "Login realizado!");
      onAuth();
    }, 1500);
  };

  const handleOtpSubmit = () => {
    if (otp.length !== 6) {
      toast.error("Código inválido");
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      toast.success("Verificação concluída!");
      onAuth();
    }, 1500);
  };

  const goBack = () => {
    if (mode === "otp") setMode("phone");
    else setMode("select");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="p-4">
        {mode !== "select" && (
          <button
            onClick={goBack}
            className="flex items-center gap-2 text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-5 w-5" />
            Voltar
          </button>
        )}
      </div>

      <AnimatePresence mode="wait">
        {/* Select Mode */}
        {mode === "select" && (
          <motion.div
            key="select"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex flex-col px-6"
          >
            {/* Logo */}
            <div className="mb-12 text-center">
              <motion.div
                className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-3xl bg-gradient-gold shadow-gold"
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.2, type: "spring" }}
              >
                <Sparkles className="h-12 w-12 text-primary-foreground" />
              </motion.div>
              <h1 className="font-display text-3xl font-bold">Kuenda</h1>
              <p className="mt-2 text-muted-foreground">
                Ganhe dinheiro assistindo anúncios
              </p>
            </div>

            {/* Auth Options */}
            <div className="space-y-3">
              <Button
                variant="gold"
                size="xl"
                className="w-full gap-3"
                onClick={() => setMode("phone")}
              >
                <Smartphone className="h-5 w-5" />
                Continuar com Telefone
              </Button>

              <Button
                variant="outline"
                size="xl"
                className="w-full gap-3"
                onClick={() => {
                  setMode("email");
                  setIsRegister(false);
                }}
              >
                <Mail className="h-5 w-5" />
                Continuar com E-mail
              </Button>
            </div>

            {/* Divider */}
            <div className="my-8 flex items-center gap-4">
              <div className="h-px flex-1 bg-border" />
              <span className="text-sm text-muted-foreground">ou</span>
              <div className="h-px flex-1 bg-border" />
            </div>

            {/* Register */}
            <Button
              variant="ghost"
              onClick={() => {
                setMode("email");
                setIsRegister(true);
              }}
              className="text-muted-foreground"
            >
              Criar nova conta
              <ChevronRight className="ml-1 h-4 w-4" />
            </Button>

            {/* Terms */}
            <p className="mt-8 text-center text-xs text-muted-foreground">
              Ao continuar, você concorda com nossos{" "}
              <button className="text-primary underline">Termos de Serviço</button>
              {" "}e{" "}
              <button className="text-primary underline">Política de Privacidade</button>
            </p>
          </motion.div>
        )}

        {/* Phone Mode */}
        {mode === "phone" && (
          <motion.div
            key="phone"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="px-6"
          >
            <h2 className="mb-2 font-display text-2xl font-bold">
              Digite seu número
            </h2>
            <p className="mb-8 text-muted-foreground">
              Enviaremos um código de verificação
            </p>

            <Card variant="default">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 rounded-lg bg-secondary px-3 py-2">
                    <span className="text-lg">🇦🇴</span>
                    <span className="font-medium">+244</span>
                  </div>
                  <Input
                    type="tel"
                    placeholder="923 456 789"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))}
                    className="border-0 bg-transparent text-lg"
                    maxLength={9}
                  />
                </div>
              </CardContent>
            </Card>

            <Button
              variant="gold"
              size="xl"
              className="mt-6 w-full"
              onClick={handlePhoneSubmit}
              disabled={isLoading || phone.length < 9}
            >
              {isLoading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <>
                  Enviar Código
                  <ChevronRight className="ml-2 h-5 w-5" />
                </>
              )}
            </Button>
          </motion.div>
        )}

        {/* Email Mode */}
        {mode === "email" && (
          <motion.div
            key="email"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="px-6"
          >
            <h2 className="mb-2 font-display text-2xl font-bold">
              {isRegister ? "Criar Conta" : "Entrar"}
            </h2>
            <p className="mb-8 text-muted-foreground">
              {isRegister
                ? "Preencha seus dados para começar"
                : "Digite seu e-mail e senha"}
            </p>

            <div className="space-y-4">
              <Card variant="default">
                <CardContent className="p-4">
                  <Input
                    type="email"
                    placeholder="seu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="border-0 bg-transparent text-lg"
                  />
                </CardContent>
              </Card>

              <Card variant="default">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <Input
                      type={showPassword ? "text" : "password"}
                      placeholder="Sua senha"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="border-0 bg-transparent text-lg"
                    />
                    <button
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-muted-foreground"
                    >
                      {showPassword ? (
                        <EyeOff className="h-5 w-5" />
                      ) : (
                        <Eye className="h-5 w-5" />
                      )}
                    </button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {!isRegister && (
              <button className="mt-3 text-sm text-primary">
                Esqueceu a senha?
              </button>
            )}

            <Button
              variant="gold"
              size="xl"
              className="mt-6 w-full"
              onClick={handleEmailSubmit}
              disabled={isLoading}
            >
              {isLoading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <>
                  {isRegister ? "Criar Conta" : "Entrar"}
                  <ChevronRight className="ml-2 h-5 w-5" />
                </>
              )}
            </Button>

            <Button
              variant="ghost"
              className="mt-4 w-full"
              onClick={() => setIsRegister(!isRegister)}
            >
              {isRegister
                ? "Já tenho uma conta"
                : "Criar nova conta"}
            </Button>
          </motion.div>
        )}

        {/* OTP Mode */}
        {mode === "otp" && (
          <motion.div
            key="otp"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="px-6"
          >
            <h2 className="mb-2 font-display text-2xl font-bold">
              Código de Verificação
            </h2>
            <p className="mb-8 text-muted-foreground">
              Digite o código enviado para +244 {phone}
            </p>

            <Card variant="default">
              <CardContent className="p-4">
                <Input
                  type="text"
                  placeholder="000000"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
                  className="border-0 bg-transparent text-center font-mono text-3xl tracking-[0.5em]"
                  maxLength={6}
                />
              </CardContent>
            </Card>

            <Button
              variant="gold"
              size="xl"
              className="mt-6 w-full"
              onClick={handleOtpSubmit}
              disabled={isLoading || otp.length !== 6}
            >
              {isLoading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <>
                  Verificar
                  <ChevronRight className="ml-2 h-5 w-5" />
                </>
              )}
            </Button>

            <Button variant="ghost" className="mt-4 w-full">
              Reenviar código
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
