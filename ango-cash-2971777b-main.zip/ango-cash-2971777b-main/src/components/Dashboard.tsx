import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Play, 
  TrendingUp, 
  Gift, 
  Star,
  ChevronRight,
  Bell,
  Eye
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface DashboardProps {
  onNavigate: (tab: string) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const balance = 12580.50;
  const pendingBalance = 2450.00;
  const dailyProgress = 65;
  const adsWatched = 13;
  const dailyLimit = 20;
  const level = "Ouro";

  return (
    <div className="min-h-screen bg-background pb-24 pt-4">
      {/* Header */}
      <motion.header 
        className="px-4 pb-4"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Bem-vindo de volta,</p>
            <h1 className="font-display text-2xl font-bold">João Silva</h1>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="gold" className="gap-1">
              <Star className="h-3 w-3" />
              {level}
            </Badge>
            <button className="relative rounded-xl bg-secondary p-3 transition-colors hover:bg-secondary/80">
              <Bell className="h-5 w-5" />
              <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground">
                3
              </span>
            </button>
          </div>
        </div>
      </motion.header>

      {/* Main Balance Card */}
      <motion.div 
        className="px-4 pb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card variant="gold" className="overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent" />
          <CardContent className="relative p-6">
            <div className="mb-4 flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Saldo Disponível</span>
              <Eye className="h-5 w-5 text-muted-foreground" />
            </div>
            <div className="mb-6">
              <span className="font-display text-4xl font-bold tracking-tight">
                {balance.toLocaleString("pt-AO", {
                  style: "currency",
                  currency: "AOA",
                })}
              </span>
            </div>
            <div className="flex items-center justify-between rounded-xl bg-secondary/50 p-3">
              <div>
                <p className="text-xs text-muted-foreground">Saldo Pendente</p>
                <p className="font-semibold text-warning">
                  {pendingBalance.toLocaleString("pt-AO", {
                    style: "currency",
                    currency: "AOA",
                  })}
                </p>
              </div>
              <TrendingUp className="h-5 w-5 text-success" />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Daily Progress */}
      <motion.div 
        className="px-4 pb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card variant="default" className="overflow-hidden">
          <CardContent className="p-5">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-display font-semibold">Progresso Diário</h3>
              <span className="text-sm text-muted-foreground">
                {adsWatched}/{dailyLimit} anúncios
              </span>
            </div>
            <Progress value={dailyProgress} variant="gold" className="mb-3 h-3" />
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">
                Faltam {dailyLimit - adsWatched} anúncios para a meta
              </span>
              <Badge variant="success">+500 AOA</Badge>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Quick Actions */}
      <motion.div 
        className="px-4 pb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <div className="grid grid-cols-2 gap-3">
          <Button
            variant="gold"
            size="lg"
            className="h-auto flex-col gap-2 py-6"
            onClick={() => onNavigate("ads")}
          >
            <Play className="h-6 w-6" />
            <span>Ver Anúncios</span>
            <Badge variant="secondary" className="bg-background/20 text-xs">
              7 disponíveis
            </Badge>
          </Button>
          <Button
            variant="premium"
            size="lg"
            className="h-auto flex-col gap-2 py-6"
            onClick={() => onNavigate("wallet")}
          >
            <Gift className="h-6 w-6" />
            <span>Sacar Agora</span>
            <Badge variant="gold" className="text-xs">
              Mín. 5.000 AOA
            </Badge>
          </Button>
        </div>
      </motion.div>

      {/* Recent Activity */}
      <motion.div 
        className="px-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-display font-semibold">Atividade Recente</h3>
          <button className="flex items-center text-sm text-primary">
            Ver tudo <ChevronRight className="h-4 w-4" />
          </button>
        </div>
        <Card variant="default">
          <CardContent className="divide-y divide-border p-0">
            {[
              { type: "ad", title: "Anúncio Premium assistido", amount: "+150 AOA", time: "Há 5 min", icon: Play },
              { type: "bonus", title: "Bônus de indicação", amount: "+500 AOA", time: "Há 2 horas", icon: Gift },
              { type: "ad", title: "Anúncio Standard assistido", amount: "+50 AOA", time: "Há 3 horas", icon: Play },
            ].map((item, index) => (
              <div key={index} className="flex items-center gap-4 p-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                  <item.icon className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{item.title}</p>
                  <p className="text-sm text-muted-foreground">{item.time}</p>
                </div>
                <span className="font-semibold text-success">{item.amount}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
