import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  Coins,
  Play,
  TrendingUp,
  Users,
  ChevronRight,
  Sparkles
} from "lucide-react";

interface OnboardingProps {
  onComplete: () => void;
}

const slides = [
  {
    icon: Coins,
    title: "Ganhe Dinheiro Real",
    subtitle: "Assista anúncios e receba em Kwanzas diretamente na sua conta",
    color: "text-primary",
    bgGradient: "from-primary/20 via-transparent to-transparent",
  },
  {
    icon: Play,
    title: "Simples e Rápido",
    subtitle: "Anúncios curtos de 15 a 60 segundos. Ganhe até 200 AOA por vídeo",
    color: "text-success",
    bgGradient: "from-success/20 via-transparent to-transparent",
  },
  {
    icon: TrendingUp,
    title: "Suba de Nível",
    subtitle: "Bronze, Prata, Ouro, Diamante. Quanto mais alto, mais você ganha",
    color: "text-warning",
    bgGradient: "from-warning/20 via-transparent to-transparent",
  },
  {
    icon: Users,
    title: "Convide Amigos",
    subtitle: "Ganhe bônus de 500 AOA por cada amigo que se cadastrar",
    color: "text-primary",
    bgGradient: "from-primary/20 via-transparent to-transparent",
  },
];

export function Onboarding({ onComplete }: OnboardingProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      onComplete();
    }
  };

  const skipOnboarding = () => {
    onComplete();
  };

  const slide = slides[currentSlide];
  const Icon = slide.icon;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-background">
      {/* Skip Button */}
      <div className="flex justify-end p-4">
        <button
          onClick={skipOnboarding}
          className="text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          Pular
        </button>
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col items-center justify-center px-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
            className="text-center"
          >
            {/* Icon */}
            <motion.div
              className={`relative mx-auto mb-8 flex h-32 w-32 items-center justify-center rounded-3xl bg-gradient-to-br ${slide.bgGradient}`}
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1, type: "spring" }}
            >
              <div className={`absolute inset-0 rounded-3xl bg-gradient-to-br ${slide.bgGradient} animate-pulse`} />
              <Icon className={`relative h-16 w-16 ${slide.color}`} />
              <Sparkles className="absolute -right-2 -top-2 h-6 w-6 text-primary animate-pulse" />
            </motion.div>

            {/* Title */}
            <motion.h1
              className="mb-4 font-display text-3xl font-bold"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              {slide.title}
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              className="mx-auto max-w-xs text-lg text-muted-foreground"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              {slide.subtitle}
            </motion.p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom */}
      <div className="p-6 safe-area-inset-bottom">
        {/* Progress Dots */}
        <div className="mb-6 flex justify-center gap-2">
          {slides.map((_, index) => (
            <motion.div
              key={index}
              className={`h-2 rounded-full transition-all duration-300 ${
                index === currentSlide
                  ? "w-8 bg-primary"
                  : index < currentSlide
                  ? "w-2 bg-primary/50"
                  : "w-2 bg-muted"
              }`}
              animate={{
                scale: index === currentSlide ? 1 : 0.8,
              }}
            />
          ))}
        </div>

        {/* Continue Button */}
        <Button
          variant="gold"
          size="xl"
          className="w-full gap-2"
          onClick={nextSlide}
        >
          {currentSlide < slides.length - 1 ? (
            <>
              Continuar
              <ChevronRight className="h-5 w-5" />
            </>
          ) : (
            <>
              Começar a Ganhar
              <Sparkles className="h-5 w-5" />
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
