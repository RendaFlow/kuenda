import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  User,
  Settings,
  Bell,
  Shield,
  HelpCircle,
  LogOut,
  ChevronRight,
  Star,
  Crown,
  Award,
  FileText,
  Lock
} from "lucide-react";

const levelInfo = {
  current: "Ouro",
  progress: 68,
  nextLevel: "Diamante",
  pointsNeeded: 3200,
  currentPoints: 2176,
};

const menuItems = [
  { icon: Bell, label: "Notificações", badge: "3" },
  { icon: Shield, label: "Segurança" },
  { icon: Lock, label: "Privacidade" },
  { icon: FileText, label: "Termos e Condições" },
  { icon: HelpCircle, label: "Ajuda & Suporte" },
  { icon: Settings, label: "Configurações" },
];

export function ProfileScreen() {
  const user = {
    name: "João Silva",
    email: "joao.silva@email.com",
    phone: "+244 923 456 789",
    level: "Ouro",
    verified: true,
    joinDate: "Janeiro 2024",
    totalEarnings: 125800,
    adsWatched: 342,
  };

  const getLevelVariant = (level: string) => {
    switch (level) {
      case "Bronze": return "bronze";
      case "Prata": return "silver";
      case "Ouro": return "gold";
      case "Diamante": return "diamond";
      default: return "secondary";
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24 pt-4">
      {/* Header */}
      <motion.header 
        className="px-4 pb-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="font-display text-2xl font-bold">Perfil</h1>
        <p className="text-muted-foreground">Gerencie sua conta</p>
      </motion.header>

      {/* Profile Card */}
      <motion.div 
        className="px-4 pb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card variant="gold">
          <CardContent className="p-5">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-background/20 text-2xl font-bold">
                  {user.name.charAt(0)}
                </div>
                {user.verified && (
                  <div className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-success">
                    <Shield className="h-3 w-3 text-success-foreground" />
                  </div>
                )}
              </div>
              <div className="flex-1">
                <h2 className="font-display text-xl font-bold">{user.name}</h2>
                <p className="text-sm opacity-80">{user.email}</p>
                <div className="mt-2 flex items-center gap-2">
                  <Badge variant={getLevelVariant(user.level) as any} className="gap-1">
                    <Star className="h-3 w-3" />
                    {user.level}
                  </Badge>
                  {user.verified && (
                    <Badge variant="success">Verificado</Badge>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Level Progress */}
      <motion.div 
        className="px-4 pb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card variant="default">
          <CardContent className="p-5">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Crown className="h-5 w-5 text-primary" />
                <span className="font-display font-semibold">Progresso de Nível</span>
              </div>
              <Badge variant="diamond">{levelInfo.nextLevel}</Badge>
            </div>
            <Progress value={levelInfo.progress} variant="gold" className="mb-3 h-3" />
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">
                {levelInfo.currentPoints.toLocaleString()} / {levelInfo.pointsNeeded.toLocaleString()} pontos
              </span>
              <span className="font-medium text-primary">
                {levelInfo.progress}%
              </span>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Stats */}
      <motion.div 
        className="px-4 pb-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <div className="grid grid-cols-2 gap-3">
          <Card variant="default">
            <CardContent className="p-4 text-center">
              <Award className="mx-auto mb-2 h-6 w-6 text-primary" />
              <p className="font-display text-xl font-bold">
                {user.totalEarnings.toLocaleString()}
              </p>
              <p className="text-xs text-muted-foreground">AOA ganhos</p>
            </CardContent>
          </Card>
          <Card variant="default">
            <CardContent className="p-4 text-center">
              <Star className="mx-auto mb-2 h-6 w-6 text-primary" />
              <p className="font-display text-xl font-bold">{user.adsWatched}</p>
              <p className="text-xs text-muted-foreground">Anúncios assistidos</p>
            </CardContent>
          </Card>
        </div>
      </motion.div>

      {/* Menu Items */}
      <motion.div 
        className="px-4 pb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card variant="default">
          <CardContent className="divide-y divide-border p-0">
            {menuItems.map((item, index) => (
              <button
                key={index}
                className="flex w-full items-center gap-4 p-4 transition-colors hover:bg-secondary/50"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                  <item.icon className="h-5 w-5 text-primary" />
                </div>
                <span className="flex-1 text-left font-medium">{item.label}</span>
                {item.badge ? (
                  <Badge variant="destructive">{item.badge}</Badge>
                ) : (
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                )}
              </button>
            ))}
          </CardContent>
        </Card>
      </motion.div>

      {/* Logout */}
      <motion.div 
        className="px-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <Button variant="destructive" className="w-full gap-2">
          <LogOut className="h-5 w-5" />
          Sair da Conta
        </Button>
        <p className="mt-4 text-center text-xs text-muted-foreground">
          Membro desde {user.joinDate}
        </p>
      </motion.div>
    </div>
  );
}
