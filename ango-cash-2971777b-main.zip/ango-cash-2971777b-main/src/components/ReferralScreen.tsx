import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Users,
  Copy,
  Share2,
  Gift,
  TrendingUp,
  CheckCircle,
  ChevronRight,
  Link2,
  UserPlus
} from "lucide-react";
import { toast } from "sonner";

interface Referral {
  id: string;
  name: string;
  status: "active" | "pending";
  earnings: number;
  joinedDate: string;
}

const mockReferrals: Referral[] = [
  { id: "1", name: "Maria S.", status: "active", earnings: 2500, joinedDate: "Há 2 dias" },
  { id: "2", name: "Pedro M.", status: "active", earnings: 1800, joinedDate: "Há 5 dias" },
  { id: "3", name: "Ana C.", status: "pending", earnings: 0, joinedDate: "Há 1 dia" },
  { id: "4", name: "Carlos R.", status: "active", earnings: 3200, joinedDate: "Há 1 semana" },
];

export function ReferralScreen() {
  const referralCode = "JOAO2024";
  const referralLink = `https://kuenda.ao/r/${referralCode}`;
  const totalEarnings = 12500;
  const activeReferrals = 8;
  const pendingReferrals = 2;

  const copyToClipboard = (text: string, message: string) => {
    navigator.clipboard.writeText(text);
    toast.success(message);
  };

  return (
    <div className="min-h-screen bg-background pb-24 pt-4">
      {/* Header */}
      <motion.header 
        className="px-4 pb-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="font-display text-2xl font-bold">Indicar Amigos</h1>
        <p className="text-muted-foreground">Ganhe por cada indicação</p>
      </motion.header>

      {/* Earnings Card */}
      <motion.div 
        className="px-4 pb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card variant="gold">
          <CardContent className="p-5">
            <div className="mb-4 flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-background/20">
                <Gift className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm opacity-80">Ganhos com indicações</p>
                <p className="font-display text-2xl font-bold">
                  {totalEarnings.toLocaleString("pt-AO")} AOA
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl bg-background/10 p-3 text-center">
                <p className="font-display text-xl font-bold">{activeReferrals}</p>
                <p className="text-xs opacity-80">Ativos</p>
              </div>
              <div className="rounded-xl bg-background/10 p-3 text-center">
                <p className="font-display text-xl font-bold">{pendingReferrals}</p>
                <p className="text-xs opacity-80">Pendentes</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Referral Code */}
      <motion.div 
        className="px-4 pb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card variant="default">
          <CardContent className="p-5">
            <h3 className="mb-3 font-display font-semibold">Seu Código</h3>
            <div className="mb-4 flex items-center gap-2">
              <div className="flex-1 rounded-xl bg-secondary p-4 text-center">
                <span className="font-mono text-2xl font-bold tracking-widest text-primary">
                  {referralCode}
                </span>
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={() => copyToClipboard(referralCode, "Código copiado!")}
              >
                <Copy className="h-5 w-5" />
              </Button>
            </div>

            <h3 className="mb-3 font-display font-semibold">Seu Link</h3>
            <div className="mb-4 flex items-center gap-2">
              <div className="flex-1 overflow-hidden rounded-xl bg-secondary p-3">
                <p className="truncate text-sm text-muted-foreground">
                  {referralLink}
                </p>
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={() => copyToClipboard(referralLink, "Link copiado!")}
              >
                <Link2 className="h-5 w-5" />
              </Button>
            </div>

            <Button variant="gold" className="w-full gap-2">
              <Share2 className="h-5 w-5" />
              Compartilhar
            </Button>
          </CardContent>
        </Card>
      </motion.div>

      {/* How it Works */}
      <motion.div 
        className="px-4 pb-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <h2 className="mb-3 font-display font-semibold">Como Funciona</h2>
        <Card variant="premium">
          <CardContent className="p-5">
            <div className="space-y-4">
              {[
                { step: 1, title: "Compartilhe seu código", desc: "Envie para amigos e família" },
                { step: 2, title: "Eles se cadastram", desc: "Usando seu código de indicação" },
                { step: 3, title: "Vocês ganham", desc: "500 AOA para cada, quando assistirem 10 anúncios" },
              ].map((item, index) => (
                <div key={index} className="flex items-start gap-4">
                  <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary/20 font-bold text-primary">
                    {item.step}
                  </div>
                  <div>
                    <p className="font-medium">{item.title}</p>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Referrals List */}
      <motion.div 
        className="px-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display font-semibold">Suas Indicações</h2>
          <Badge variant="secondary">{mockReferrals.length} total</Badge>
        </div>

        <div className="space-y-2">
          {mockReferrals.map((referral, index) => (
            <motion.div
              key={referral.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.05 * index }}
            >
              <Card variant="default">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 font-semibold text-primary">
                    {referral.name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{referral.name}</p>
                      {referral.status === "active" ? (
                        <CheckCircle className="h-4 w-4 text-success" />
                      ) : (
                        <Badge variant="warning">Pendente</Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{referral.joinedDate}</p>
                  </div>
                  {referral.status === "active" && (
                    <span className="font-semibold text-success">
                      +{referral.earnings.toLocaleString("pt-AO")} AOA
                    </span>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
