import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Wallet as WalletIcon,
  ArrowUpRight,
  ArrowDownLeft,
  Clock,
  CheckCircle,
  XCircle,
  Building2,
  Smartphone,
  ChevronRight,
  CreditCard
} from "lucide-react";

type TransactionStatus = "completed" | "pending" | "failed";
type TransactionType = "deposit" | "withdraw" | "earning";

interface Transaction {
  id: string;
  type: TransactionType;
  title: string;
  amount: number;
  status: TransactionStatus;
  date: string;
  method?: string;
}

const mockTransactions: Transaction[] = [
  { id: "1", type: "earning", title: "Ganhos com anúncios", amount: 450, status: "completed", date: "Hoje, 14:30" },
  { id: "2", type: "withdraw", title: "Saque para Multicaixa", amount: -5000, status: "pending", date: "Ontem, 09:15", method: "Multicaixa Express" },
  { id: "3", type: "deposit", title: "Depósito recebido", amount: 10000, status: "completed", date: "15 Jan, 16:45", method: "Transferência Bancária" },
  { id: "4", type: "earning", title: "Bônus de indicação", amount: 500, status: "completed", date: "14 Jan, 11:20" },
  { id: "5", type: "withdraw", title: "Saque para conta bancária", amount: -8000, status: "completed", date: "10 Jan, 10:00", method: "BAI" },
];

export function WalletScreen() {
  const [activeTab, setActiveTab] = useState<"all" | "deposits" | "withdrawals">("all");
  const balance = 12580.50;
  const pendingBalance = 2450.00;

  const getStatusIcon = (status: TransactionStatus) => {
    switch (status) {
      case "completed": return <CheckCircle className="h-4 w-4 text-success" />;
      case "pending": return <Clock className="h-4 w-4 text-warning" />;
      case "failed": return <XCircle className="h-4 w-4 text-destructive" />;
    }
  };

  const getStatusBadge = (status: TransactionStatus) => {
    switch (status) {
      case "completed": return <Badge variant="success">Concluído</Badge>;
      case "pending": return <Badge variant="warning">Pendente</Badge>;
      case "failed": return <Badge variant="destructive">Falhou</Badge>;
    }
  };

  const getTypeIcon = (type: TransactionType) => {
    switch (type) {
      case "deposit": return <ArrowDownLeft className="h-5 w-5 text-success" />;
      case "withdraw": return <ArrowUpRight className="h-5 w-5 text-destructive" />;
      case "earning": return <WalletIcon className="h-5 w-5 text-primary" />;
    }
  };

  const filteredTransactions = mockTransactions.filter(t => {
    if (activeTab === "all") return true;
    if (activeTab === "deposits") return t.type === "deposit" || t.type === "earning";
    return t.type === "withdraw";
  });

  return (
    <div className="min-h-screen bg-background pb-24 pt-4">
      {/* Header */}
      <motion.header 
        className="px-4 pb-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="font-display text-2xl font-bold">Carteira</h1>
        <p className="text-muted-foreground">Gerencie seus ganhos</p>
      </motion.header>

      {/* Balance Cards */}
      <motion.div 
        className="px-4 pb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card variant="gold" className="mb-3">
          <CardContent className="p-5">
            <p className="mb-1 text-sm text-muted-foreground">Saldo Disponível</p>
            <p className="font-display text-3xl font-bold">
              {balance.toLocaleString("pt-AO", { style: "currency", currency: "AOA" })}
            </p>
          </CardContent>
        </Card>

        <Card variant="default">
          <CardContent className="flex items-center justify-between p-4">
            <div>
              <p className="text-sm text-muted-foreground">Saldo Pendente</p>
              <p className="font-semibold text-warning">
                {pendingBalance.toLocaleString("pt-AO", { style: "currency", currency: "AOA" })}
              </p>
            </div>
            <Clock className="h-5 w-5 text-warning" />
          </CardContent>
        </Card>
      </motion.div>

      {/* Quick Actions */}
      <motion.div 
        className="px-4 pb-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <div className="grid grid-cols-2 gap-3">
          <Button variant="gold" size="lg" className="h-auto gap-3 py-4">
            <ArrowUpRight className="h-5 w-5" />
            Sacar
          </Button>
          <Button variant="outline" size="lg" className="h-auto gap-3 py-4">
            <ArrowDownLeft className="h-5 w-5" />
            Depositar
          </Button>
        </div>
      </motion.div>

      {/* Payment Methods */}
      <motion.div 
        className="px-4 pb-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <h2 className="mb-3 font-display font-semibold">Métodos de Pagamento</h2>
        <div className="space-y-2">
          {[
            { icon: CreditCard, name: "Multicaixa Express", status: "Configurado" },
            { icon: Building2, name: "Conta Bancária", status: "Adicionar" },
            { icon: Smartphone, name: "Unitel Money", status: "Adicionar" },
          ].map((method, index) => (
            <Card key={index} variant="default">
              <CardContent className="flex items-center gap-4 p-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                  <method.icon className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{method.name}</p>
                </div>
                {method.status === "Configurado" ? (
                  <Badge variant="success">{method.status}</Badge>
                ) : (
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </motion.div>

      {/* Transaction History */}
      <motion.div 
        className="px-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <h2 className="mb-3 font-display font-semibold">Histórico</h2>
        
        {/* Tabs */}
        <div className="mb-4 flex gap-2">
          {[
            { id: "all", label: "Todos" },
            { id: "deposits", label: "Entradas" },
            { id: "withdrawals", label: "Saídas" },
          ].map((tab) => (
            <Button
              key={tab.id}
              variant={activeTab === tab.id ? "default" : "ghost"}
              size="sm"
              onClick={() => setActiveTab(tab.id as any)}
            >
              {tab.label}
            </Button>
          ))}
        </div>

        {/* Transactions List */}
        <div className="space-y-2">
          {filteredTransactions.map((transaction, index) => (
            <motion.div
              key={transaction.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.05 * index }}
            >
              <Card variant="default">
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary">
                    {getTypeIcon(transaction.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{transaction.title}</p>
                      {getStatusIcon(transaction.status)}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {transaction.date}
                      {transaction.method && ` • ${transaction.method}`}
                    </p>
                  </div>
                  <p className={`font-semibold ${transaction.amount > 0 ? "text-success" : "text-foreground"}`}>
                    {transaction.amount > 0 ? "+" : ""}
                    {transaction.amount.toLocaleString("pt-AO")} AOA
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
