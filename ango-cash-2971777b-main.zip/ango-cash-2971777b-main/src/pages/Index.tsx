import { useState, useEffect } from "react";
import { AnimatePresence } from "framer-motion";
import { Onboarding } from "@/components/Onboarding";
import { AuthScreen } from "@/components/AuthScreen";
import { Dashboard } from "@/components/Dashboard";
import { AdsScreen } from "@/components/AdsScreen";
import { WalletScreen } from "@/components/WalletScreen";
import { ReferralScreen } from "@/components/ReferralScreen";
import { ProfileScreen } from "@/components/ProfileScreen";
import { BottomNav } from "@/components/BottomNav";

type AppState = "onboarding" | "auth" | "app";

const Index = () => {
  const [appState, setAppState] = useState<AppState>("onboarding");
  const [activeTab, setActiveTab] = useState("home");

  // Simulate checking if user has seen onboarding
  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem("kuenda_onboarding");
    const isAuthenticated = localStorage.getItem("kuenda_auth");
    
    if (hasSeenOnboarding && isAuthenticated) {
      setAppState("app");
    } else if (hasSeenOnboarding) {
      setAppState("auth");
    }
  }, []);

  const handleOnboardingComplete = () => {
    localStorage.setItem("kuenda_onboarding", "true");
    setAppState("auth");
  };

  const handleAuth = () => {
    localStorage.setItem("kuenda_auth", "true");
    setAppState("app");
  };

  const renderActiveScreen = () => {
    switch (activeTab) {
      case "home":
        return <Dashboard onNavigate={setActiveTab} />;
      case "ads":
        return <AdsScreen />;
      case "wallet":
        return <WalletScreen />;
      case "referral":
        return <ReferralScreen />;
      case "profile":
        return <ProfileScreen />;
      default:
        return <Dashboard onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <AnimatePresence mode="wait">
        {appState === "onboarding" && (
          <Onboarding onComplete={handleOnboardingComplete} />
        )}

        {appState === "auth" && (
          <AuthScreen onAuth={handleAuth} />
        )}

        {appState === "app" && (
          <>
            {renderActiveScreen()}
            <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Index;
